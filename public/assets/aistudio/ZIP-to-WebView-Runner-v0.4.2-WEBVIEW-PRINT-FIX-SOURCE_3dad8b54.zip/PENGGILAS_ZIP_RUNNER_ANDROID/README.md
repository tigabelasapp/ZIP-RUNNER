# ZIP-to-WebView Runner v0.4.2 — PENGGILAS

Native Android app that serves HTML/CSS/JavaScript projects from a selected ZIP archive through a loopback HTTP server and Android WebView.

## v0.4.2 changes
- Reads individual entries directly from the ZIP using `java.util.zip.ZipFile`; it does not extract the project tree.
- Copies the selected ZIP to app-private storage, then serves requested paths on `http://127.0.0.1:8080/`.
- Finds `index.html`, then `default.html`, then the shallowest HTML page.
- Supports relative paths, multiple HTML pages, CSS, JS/ES modules, JSON, images, fonts, and common media types.
- Validates entry paths and limits archive entry count and declared expanded size.
- Uses Android's document picker; no broad storage permission is required.

## Build APK
1. Upload the contents of this project folder to the root of a GitHub repository.
2. Open **Actions** and run **Build ZIP Runner APK** (or push to `main`/`master`).
3. Download the `PENGGILAS-ZIP-RUNNER-debug-apk` artifact from a successful run.

## Important limitations
- This version copies the ZIP archive into app-private storage but does not extract its files.
- It supports static web apps. It does not run PHP, Python, Node.js, or other server-side backends.
- Service workers/PWA installation, HTTPS-only APIs, special permissions, remote APIs, and advanced WebView features may need extra integration.
- Only open ZIP files you trust; HTML/JavaScript executes inside WebView.

## Verification status
Source archive and Kotlin changes are packaged. An Android APK has **not** been compiled or device-tested in this environment; use the GitHub Actions workflow to build and verify it.


## v0.4.2 Fullscreen mode
When a ZIP app starts, Runner controls and Android system bars are hidden. Press Android Back to navigate backward; at the start page, Back closes the project and restores the ZIP picker. Native print and download bridges from v0.4.0 are retained.
\n\nPrint fix v0.4.2: captures the calling HTML document (including iframe reports) and prints that HTML snapshot using a dedicated Android WebView with the original local-server URL as its base URL.\n